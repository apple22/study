jquery.morphing.js
====================

morphing effect

Demo:  
http://blog.makitasako.com/jquery.morphing.js/test/

## Options
| Key | Value |
|:-----|:-----|
| numVert | 円の粒度。デフォルトは6。 |
| spring | バネ運動の動作数値。デフォルトは0.005 |
| friction | 摩擦運動の動作数値。デフォルトは0.90 |
| radius | Canvasの表示半径。デフォルトは90 |
| fps | デフォルトは45。 |