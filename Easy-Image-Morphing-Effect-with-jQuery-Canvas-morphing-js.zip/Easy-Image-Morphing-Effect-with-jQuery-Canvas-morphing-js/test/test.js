$(function(){

  $('.js-morphing').morphing();

});