function hello(){
	console.log("hi");
	alert("hi");
}