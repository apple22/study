// 자바스크립트
document.querySelector("#btn").addEventListener("click", function(event) {  
});


// 제이쿼리
$("#btn").on("click", function(event) {  
});
