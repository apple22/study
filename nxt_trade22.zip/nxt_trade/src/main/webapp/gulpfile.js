
const gulp = require('gulp');
const uglify = require('gulp-uglify');
const concat = require('gulp-concat');
const sourcemaps = require('gulp-sourcemaps');
const scss = require('gulp-sass')(require('sass'));
const cleanCss = require("gulp-clean-css");

const paths = {
	js: ['./js/*.js'],
	scss: ['./sass/*.scss'],
	css: ['./css/*.css']
};

var scssOptions = {
	outputStyle: "expanded",
	indentType: "tab",
	indentWidth: 1,
	precision: 6,
	sourceComments: true
};


// SCSS Compile Task
gulp.task('scss', function() {
	return gulp.src(paths.scss)
		.pipe(sourcemaps.init())
		.pipe(scss(scssOptions).on('error', scss.logError))
		.pipe(sourcemaps.write('.'))
		.pipe(gulp.dest('css'));
});

//clean css
gulp.task('cleanCss', function() {
		return gulp.src(paths.css)
		.pipe(cleanCss({ compatibiliy: 'ie8' })) 
        .pipe(gulp.dest("css"))
});

// Minify JavaScript Task
gulp.task('uglify', function() {
	return gulp.src(paths.js)
		.pipe(concat('main.min.js')) // Merge
		.pipe(uglify()) // Minify
		.pipe(gulp.dest('dist/js'));
});

// Watch Task
gulp.task('watch', function() {
	gulp.watch(paths.js, gulp.series('uglify'));
	gulp.watch(paths.scss, gulp.series('scss'));
});

// Default Task
gulp.task('default', gulp.parallel('uglify', 'scss', 'cleanCss','watch'));